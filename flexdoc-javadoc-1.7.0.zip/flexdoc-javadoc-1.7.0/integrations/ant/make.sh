#!/bin/sh
#======================================================================
# Linux shell script to run Ant build demo
#======================================================================  

export ANT_HOME="/home/user/apache-ant-1.10.5"
export JAVA_HOME="/home/user/jdk1.8" 

${ANT_HOME}/bin/ant demo

sleep 10
