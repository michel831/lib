package java8;

import java.lang.annotation.*;

/**
* Indicates that the numeric value cannot be negative
*/
@Documented
@Target({ElementType.TYPE_USE})
public @interface NonNegative
{
}
