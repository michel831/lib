package java8;

import java.awt.*;
import javax.swing.*;

/**
* Draws an <i>empty</i> icon.
* Useful to reserve some rectangle space.
*/
public class EmptyIcon implements Icon
{
  protected @NonNegative int width;
  protected @NonNegative int height;

  //--------------------------------------------------------------------
  public EmptyIcon()
  {
    width = 0;
    height = 0;
  }

  //--------------------------------------------------------------------
  public EmptyIcon (@NonNegative int width, @NonNegative int height)
  {
    this.width = width;
    this.height = height;
  }

  //--------------------------------------------------------------------
  public int getIconWidth()
  {
    return width;
  }

  //--------------------------------------------------------------------
  public int getIconHeight()
  {
    return height;
  }

  //--------------------------------------------------------------------
  public void paintIcon (Component c, Graphics g, int x, int y)
  {
  }

  //--------------------------------------------------------------------
}
