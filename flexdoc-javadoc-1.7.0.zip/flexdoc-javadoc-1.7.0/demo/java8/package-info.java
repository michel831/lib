/**
* A few Java classes to demonstrate FlexDoc/Doclet capabilities and
* how it handles some of Java 8 features.
*
* @prj:type demo
*/
@Author("Filigris Works")
package java8;