package java8;

import java.lang.annotation.*;

@Documented
public @interface Author
{
  String value();
}
