package java8;

import java.lang.annotation.*;

@Documented
public @interface Reviews
{
  Review[] value();
}
